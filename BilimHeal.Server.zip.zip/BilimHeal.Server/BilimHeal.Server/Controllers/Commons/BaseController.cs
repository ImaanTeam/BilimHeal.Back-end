﻿using Microsoft.AspNetCore.Mvc;

namespace BilimHeal.Server.API.Controllers.Commons;

[ApiController]
[Route("api/[controller]")]
public class BaseController : ControllerBase
{
}
