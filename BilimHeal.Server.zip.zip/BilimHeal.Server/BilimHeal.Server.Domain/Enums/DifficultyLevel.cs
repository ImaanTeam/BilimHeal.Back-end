﻿namespace BilimHeal.Server.Domain.Enums;

public enum DifficultyLevel
{
    Easy,
    Medium,
    Hard
}
