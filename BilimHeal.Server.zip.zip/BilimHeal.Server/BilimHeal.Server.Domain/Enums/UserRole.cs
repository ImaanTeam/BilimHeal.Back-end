﻿using BilimHeal.Server.Domain.Commons;

namespace BilimHeal.Server.Domain.Enums;

public enum UserRole
{
    User = 0,
    Admin,
    Teacher
}
