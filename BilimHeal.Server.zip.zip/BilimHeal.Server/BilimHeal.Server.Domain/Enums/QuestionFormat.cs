﻿namespace BilimHeal.Server.Domain.Enums;

public enum QuestionFormat
{
    MultipleCorrectAnswers,
    TrueFalse,
    ShortAnswer
}
