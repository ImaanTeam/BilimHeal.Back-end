﻿namespace BilimHeal.Server.Service.DTOs.Users.Logins;

public class LoginResultDto
{
    public string Token { get; set; }
}
