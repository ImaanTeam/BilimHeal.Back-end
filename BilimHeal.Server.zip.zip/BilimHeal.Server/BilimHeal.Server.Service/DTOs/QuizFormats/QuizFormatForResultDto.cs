﻿namespace BilimHeal.Server.Service.DTOs.QuizFormats;

public class QuizFormatForResultDto
{
    public long Id { get; set; }
    public string Description { get; set; }
}
