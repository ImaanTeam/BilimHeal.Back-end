﻿namespace BilimHeal.Server.Service.DTOs.TrueFalseQuizes;

public class TrueFalseQuizForCreationDto
{
    public string Question { get; set; }
    public bool Answer { get; set; }
    public short Format { get; set; }
}
