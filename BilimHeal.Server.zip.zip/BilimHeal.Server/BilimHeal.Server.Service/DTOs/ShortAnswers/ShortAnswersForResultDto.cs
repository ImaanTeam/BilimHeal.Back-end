﻿namespace BilimHeal.Server.Service.DTOs.ShortAnswers;

public class ShortAnswersForResultDto
{
    public string Question { get; set; }
    public string UserAnswer { get; set; }
    public string Answer { get; set; }
    public short Format { get; set; }
}
