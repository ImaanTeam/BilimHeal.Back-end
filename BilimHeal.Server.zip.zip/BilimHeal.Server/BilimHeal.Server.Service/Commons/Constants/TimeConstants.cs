﻿namespace BilimHeal.Server.Service.Commons.Constants;

public class TimeConstants
{
    public const int UTC = 5;
}
